-- MySQL dump 10.13  Distrib 5.5.42, for osx10.6 (i386)
--
-- Host: localhost    Database: MirabelleMakeup
-- ------------------------------------------------------
-- Server version	5.5.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_usermeta`
--
-- WHERE:  1 LIMIT 0,10000

LOCK TABLES `wp_usermeta` WRITE;
/*!40000 ALTER TABLE `wp_usermeta` DISABLE KEYS */;
INSERT  IGNORE INTO `wp_usermeta` VALUES (1,1,'nickname','root'),(2,1,'first_name',''),(3,1,'last_name',''),(4,1,'description',''),(5,1,'rich_editing','true'),(6,1,'comment_shortcuts','false'),(7,1,'admin_color','fresh'),(8,1,'use_ssl','0'),(9,1,'show_admin_bar_front','true'),(10,1,'wp_capabilities','a:1:{s:13:\"administrator\";b:1;}'),(11,1,'wp_user_level','10'),(12,1,'dismissed_wp_pointers',''),(13,1,'show_welcome_panel','1'),(14,1,'session_tokens','a:2:{s:64:\"5aa684d0df2f80436ec1afac5882ad09b6266c729f35ecf84e14e85a0be6f3e8\";a:4:{s:10:\"expiration\";i:1456033620;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:116:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/601.4.4 (KHTML, like Gecko) Version/9.0.3 Safari/601.4.4\";s:5:\"login\";i:1455860820;}s:64:\"00fe3fb9154ae25d390f97795a6d8c09dab9b9bd2594f115966ef012ded7f859\";a:4:{s:10:\"expiration\";i:1456101480;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:116:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/601.4.4 (KHTML, like Gecko) Version/9.0.3 Safari/601.4.4\";s:5:\"login\";i:1455928680;}}'),(15,1,'wp_user-settings','libraryContent=browse&editor=html&mfold=o'),(16,1,'wp_user-settings-time','1455860816'),(17,1,'wp_dashboard_quick_press_last_post_id','3'),(18,1,'wporg_favorites',''),(19,2,'nickname','erika'),(20,2,'first_name',''),(21,2,'last_name',''),(22,2,'description',''),(23,2,'rich_editing','true'),(24,2,'comment_shortcuts','false'),(25,2,'admin_color','fresh'),(26,2,'use_ssl','0'),(27,2,'show_admin_bar_front','true'),(28,2,'wp_capabilities','a:1:{s:10:\"subscriber\";b:1;}'),(29,2,'wp_user_level','0'),(30,2,'dismissed_wp_pointers',''),(31,3,'nickname','khaolak'),(32,3,'first_name',''),(33,3,'last_name',''),(34,3,'description',''),(35,3,'rich_editing','true'),(36,3,'comment_shortcuts','false'),(37,3,'admin_color','fresh'),(38,3,'use_ssl','0'),(39,3,'show_admin_bar_front','true'),(40,3,'wp_capabilities','a:1:{s:10:\"subscriber\";b:1;}'),(41,3,'wp_user_level','0'),(42,3,'dismissed_wp_pointers',''),(43,4,'nickname','@replay'),(44,4,'first_name',''),(45,4,'last_name',''),(46,4,'description',''),(47,4,'rich_editing','true'),(48,4,'comment_shortcuts','false'),(49,4,'admin_color','fresh'),(50,4,'use_ssl','0'),(51,4,'show_admin_bar_front','true'),(52,4,'wp_capabilities','a:1:{s:10:\"subscriber\";b:1;}'),(53,4,'wp_user_level','0'),(54,4,'dismissed_wp_pointers',''),(55,5,'nickname','erikagarza'),(56,5,'first_name',''),(57,5,'last_name',''),(58,5,'description',''),(59,5,'rich_editing','true'),(60,5,'comment_shortcuts','false'),(61,5,'admin_color','fresh'),(62,5,'use_ssl','0'),(63,5,'show_admin_bar_front','true'),(64,5,'wp_capabilities','a:1:{s:10:\"subscriber\";b:1;}'),(65,5,'wp_user_level','0'),(66,5,'dismissed_wp_pointers',''),(67,1,'managenav-menuscolumnshidden','a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),(68,1,'metaboxhidden_nav-menus','a:5:{i:0;s:21:\"add-post-type-project\";i:1;s:12:\"add-post_tag\";i:2;s:15:\"add-post_format\";i:3;s:20:\"add-project_category\";i:4;s:15:\"add-project_tag\";}');
/*!40000 ALTER TABLE `wp_usermeta` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-02-20 20:01:37
