-- MySQL dump 10.13  Distrib 5.5.42, for osx10.6 (i386)
--
-- Host: localhost    Database: MirabelleMakeup
-- ------------------------------------------------------
-- Server version	5.5.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_postmeta`
--
-- WHERE:  1 LIMIT 0,10000

LOCK TABLES `wp_postmeta` WRITE;
/*!40000 ALTER TABLE `wp_postmeta` DISABLE KEYS */;
INSERT  IGNORE INTO `wp_postmeta` VALUES (1,2,'_wp_page_template','default'),(2,4,'_et_pb_predefined_layout','on'),(3,4,'_et_pb_built_for_post_type','page'),(4,5,'_et_pb_predefined_layout','on'),(5,5,'_et_pb_built_for_post_type','page'),(6,6,'_et_pb_predefined_layout','on'),(7,6,'_et_pb_built_for_post_type','page'),(8,7,'_et_pb_predefined_layout','on'),(9,7,'_et_pb_built_for_post_type','page'),(10,8,'_et_pb_predefined_layout','on'),(11,8,'_et_pb_built_for_post_type','page'),(12,9,'_et_pb_predefined_layout','on'),(13,9,'_et_pb_built_for_post_type','page'),(14,10,'_et_pb_predefined_layout','on'),(15,10,'_et_pb_built_for_post_type','page'),(16,11,'_et_pb_predefined_layout','on'),(17,11,'_et_pb_built_for_post_type','page'),(18,12,'_et_pb_predefined_layout','on'),(19,12,'_et_pb_built_for_post_type','page'),(20,13,'_et_pb_predefined_layout','on'),(21,13,'_et_pb_built_for_post_type','page'),(22,14,'_et_pb_predefined_layout','on'),(23,14,'_et_pb_built_for_post_type','page'),(24,15,'_et_pb_predefined_layout','on'),(25,15,'_et_pb_built_for_post_type','page'),(26,16,'_et_pb_predefined_layout','on'),(27,16,'_et_pb_built_for_post_type','page'),(28,17,'_et_pb_predefined_layout','on'),(29,17,'_et_pb_built_for_post_type','page'),(30,18,'_et_pb_predefined_layout','on'),(31,18,'_et_pb_built_for_post_type','page'),(32,19,'_et_pb_predefined_layout','on'),(33,19,'_et_pb_built_for_post_type','page'),(34,20,'_et_pb_predefined_layout','on'),(35,20,'_et_pb_built_for_post_type','page'),(36,21,'_et_pb_predefined_layout','on'),(37,21,'_et_pb_built_for_post_type','page'),(38,22,'_et_pb_predefined_layout','on'),(39,22,'_et_pb_built_for_post_type','page'),(40,23,'_et_pb_predefined_layout','on'),(41,23,'_et_pb_built_for_post_type','page'),(42,24,'_et_pb_predefined_layout','on'),(43,24,'_et_pb_built_for_post_type','page'),(44,25,'_et_pb_predefined_layout','on'),(45,25,'_et_pb_built_for_post_type','page'),(46,26,'_et_pb_predefined_layout','on'),(47,26,'_et_pb_built_for_post_type','page'),(48,27,'_et_pb_predefined_layout','on'),(49,27,'_et_pb_built_for_post_type','page'),(50,28,'_et_pb_predefined_layout','on'),(51,28,'_et_pb_built_for_post_type','page'),(52,29,'_et_pb_predefined_layout','on'),(53,29,'_et_pb_built_for_post_type','page'),(54,30,'_et_pb_predefined_layout','on'),(55,30,'_et_pb_built_for_post_type','page'),(56,31,'_et_pb_predefined_layout','on'),(57,31,'_et_pb_built_for_post_type','page'),(58,32,'_et_pb_predefined_layout','on'),(59,32,'_et_pb_built_for_post_type','page'),(60,33,'_et_pb_predefined_layout','on'),(61,33,'_et_pb_built_for_post_type','page'),(62,34,'_et_pb_predefined_layout','on'),(63,34,'_et_pb_built_for_post_type','page'),(64,35,'_et_pb_predefined_layout','on'),(65,35,'_et_pb_built_for_post_type','page'),(66,2,'_edit_lock','1455861069:1'),(67,2,'_edit_last','1'),(68,2,'_et_pb_post_hide_nav','default'),(69,2,'_et_pb_page_layout','et_right_sidebar'),(70,2,'_et_pb_side_nav','off'),(71,2,'_et_pb_use_builder','on'),(72,2,'_et_pb_old_content','This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n\r\n...or something like this:\r\n\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\n\r\nAs a new WordPress user, you should go to <a href=\"http://localhost:8888/MirabelleMakeup/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!');
/*!40000 ALTER TABLE `wp_postmeta` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-02-18 23:53:25
